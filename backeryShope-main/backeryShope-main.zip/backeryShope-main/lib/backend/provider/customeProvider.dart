import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CustomProvider extends ChangeNotifier
{

  static  CustomProvider get(context)=> Provider.of<CustomProvider>(context);

  bool recieve ;
  changeRecive(bool r)
  {
    recieve =r ;
    notifyListeners() ;
  }




}